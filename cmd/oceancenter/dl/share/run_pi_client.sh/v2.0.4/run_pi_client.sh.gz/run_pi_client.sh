#!/bin/bash -e
# AusOcean Pi Client Launcher
#
# This script runs the AusOcean client on a Raspberry Pi.
# It detects the current user, sets up configuration and logging,
# and ensures the required binaries and config files are in place.
#
# Binaries are expected in /opt/ausocean/bin.
# Usage: ./run_pi_client.sh [user|auto]
#
# Dependencies:
#   - get_wifi_mac.sh
#   - totpgen
#   - pkg-upgrade.sh
#   - ausocean_logo.txt (optional)
#
# Options:
#   -v | -Version   Print version and exit
#   auto            Auto-detect and use the invoking user
#   <user>          Override the default 'pi' user

Version="v2.0.4"
User=pi # This can be changed using command line arguments.
BinDir=/opt/ausocean/bin
GetWifiMac=$BinDir/get_wifi_mac.sh
TotpGen=$BinDir/totpgen
PkgUpgrade=$BinDir/pkg-upgrade.sh
Logo=/opt/ausocean/doc/ausocean_logo.txt
ConfigFile=/etc/netsender.conf
LogFile="/var/log/ausocean.log"
NetsenderLogFile="/var/log/netsender/netsender.log"
URL="http://center.cloudblue.org/install"
RetryPeriod=60
WI=
MA=
Eth0IsUp=

# Don't exit script when functions we call return non-zero.
set +o errexit

if [[ "$1" == "-Version" ]] || [[ "$1" == "-v" ]]; then
  echo "$Version"
  exit 0
fi

# Overide user for testing.
if [[ -n "$1" ]]; then
  if [[ "$1" == "auto" ]]; then
    User=${SUDO_USER:-$(logname 2>/dev/null || whoami)}
  else
    User=$1
  fi
fi

# log outputs <time>:<log-level>:<message> to $LogFile
# Exits 1 in the case of a fatal log message.
function log() {
  now=$(date '+%Y-%m-%d %H:%M:%S')
  echo "$now: $1: $2" >> $LogFile
  if [[ "$1" == "Fatal" ]]; then
    exit 1
  fi
}

# isRaspbian outputs true if running on Raspbian.
# This makes it possible to run this script on non-Raspbian devices for testing.
function isRaspbian() {
  if [[ -f "/etc/os-release" && $(grep -i "Raspbian" /etc/os-release) ]]; then
    echo true
  fi
}

# getParam outputs a config param, if any.
function getParam() {
  param=$1
  cfg=$2
  val=
  while IFS= read -r line; do
    if [[ ${line:0:2} == "$param" ]]; then
      val=${line:3}
      break
    fi
  done <<< "$cfg"
  echo $val
}

# configure outputs the client type (ct param) if the client is
# configured, else nothing. A configuration is deemed to be complete
# when it includes ma, dk, and ct params. If the configuration is
# incomplete, an /install request is sent to OceanCenter to fetch a
# config.
#
# Globals used: $ConfigFile, $MA, $WI.
function configure() {
  cfg=
  if [[ -f "$ConfigFile" ]]; then
    cfg=$(cat "$ConfigFile")
  fi
  ma=$(getParam ma "$cfg")
  dk=$(getParam dk "$cfg")
  ct=$(getParam ct "$cfg")
  if [[ -n "$cfg" ]] && [[ -n "$ma" ]] && [[ -n "$dk" ]] && [[ -n "$ct" ]]; then
    log "Info" "$ConfigFile is complete"
    echo $ct
    return
  fi

  if [[ -z "$ma" ]]; then
    ma="$MA"
  fi
  if [[ -z "$dk" ]]; then
    dk=$(bash -c "$TotpGen")
    if [[ $? -ne 0 ]]; then
      log "Fatal" "$TotpGen failed"
    fi
    log "Info" "Generated device key: $dk"
  fi

  # Get config from OceanCenter.
  url="$URL?wi=$WI&ma=$ma&dk=$dk"
  log "Info" "GET $url"
  tmpFile="/tmp/netsender.conf"
  curl -s -o "$tmpFile" "$url"
  if [[ $? -ne 0 ]]; then
    log "Error" "could not get $url"
    return
  fi
  resp=$(cat "$tmpFile")
  if [[ $? -ne 0 ]]; then
    log "Error" "could not read $tmpFile"
    return
  fi
  er=$(getParam er "$resp")
  if [[ -n "$er" ]]; then
    log "Error" "$er"
    return
  fi

  if [[ "$cfg" == "$resp" ]]; then
    log "Info" "$ConfigFile unchanged."
  else
    sudo cp -f $tmpFile $ConfigFile
    sudo chown "$User" $ConfigFile
    log "Info" "$ConfigFile updated."
  fi

  ct=$(getParam ct "$resp")
  if [[ -z "$ct" ]]; then
    return
  fi

  log "Info" "Configuration complete. Client type: $ct"
  echo $ct
}

wifi_bt_off() {
    log "Info" "eth0 up; silencing Wi-Fi radio (runtime only)."

    # Stop managers so they don't respawn wlan0.
    sudo systemctl stop wpa_supplicant@wlan0.service 2>/dev/null || true
    sudo systemctl stop wpa_supplicant.service 2>/dev/null || true
    sudo dhcpcd -k wlan0 2>/dev/null || true

    # Bring interface down.
    sudo ip link set wlan0 down 2>/dev/null || true
    sleep 1

    # Kill RF at the radio level (most important for interference).
    sudo rfkill block wifi
    # BT can also add 2.4 GHz noise.
    sudo rfkill block bluetooth

    sleep 2

    # Unload the Wi-Fi driver so nothing can transmit.
    # (Pi uses brcmfmac; cfg80211/brcmutil are deps. Ignore errors if already unloaded.)
    sudo modprobe -r brcmfmac brcmutil cfg80211 2>/dev/null || true

    # Debug: show final state.
    log "Info" "Wi-Fi rfkill + module unload applied."
    ip -brief link show wlan0 | while read -r l; do log "Info" "ip-brief: $l"; done
    log "Info" "operstate: $(cat /sys/class/net/wlan0/operstate 2>/dev/null || echo n/a)"
    log "Info" "rfkill: $(rfkill list 2>/dev/null | tr '\n' '|' )"
    log "Info" "iw dev: $(iw dev 2>/dev/null | tr '\n' '|' )"
}

wifi_bt_on() {
    log "Info" "eth0 down; restoring Wi-Fi (runtime only)."

    # Reload driver and radio.
    sudo modprobe cfg80211 brcmutil brcmfmac 2>/dev/null || true
    sudo rfkill unblock wifi
    sudo rfkill unblock bluetooth

    # Start managers again and bring link up.
    sudo systemctl start wpa_supplicant@wlan0.service 2>/dev/null || sudo systemctl start wpa_supplicant.service 2>/dev/null || true
    sudo ip link set wlan0 up 2>/dev/null || true
    sudo dhcpcd -n wlan0 2>/dev/null || true

    # Debug after restore.
    log "Info" "Wi-Fi restored."
    ip -brief link show wlan0 | while read -r l; do log "Info" "ip-brief: $l"; done
    log "Info" "operstate: $(cat /sys/class/net/wlan0/operstate 2>/dev/null || echo n/a)"
    log "Info" "rfkill: $(rfkill list 2>/dev/null | tr '\n' '|' )"
}

# Updates /etc/ssh/banner to contain the ausocean logo, the device type, and
# MAC address to allow for easier differentiation of pis when testing.
update_ssh_banner() {
    # Update the ssh config to enable banners.
    sudo sed -i "s~#Banner none~Banner $Logo~" /etc/ssh/sshd_config
    # If ausocean_logo.txt does not exist, a blank file will still be created,
    # so it is optional.
    sudo cat $Logo > /etc/ssh/banner
    sudo echo "Device Type: $CT, MAC: $MA" >> /etc/ssh/banner
}

if [[ ! -f "$LogFile" ]]; then
  sudo touch "$LogFile"
fi
log "Info" "run_pi_client.sh $Version"
log "Info" "Running as user: $User"

# Check for pre-requisite files and directories.
if [[ ! -f "$GetWifiMac" || ! -x "$GetWifiMac" ]]; then
  log "Fatal" "$GetWifiMac not found"
fi
if [[ ! -f "$TotpGen" || ! -x "$TotpGen" ]]; then
  log "Fatal" "$TotpGen not found"
fi
if [[ ! -f "$PkgUpgrade" || ! -x "$PkgUpgrade" ]]; then
  log "Fatal" "$PkgUpgrade not found"
fi
if [[ ! -f "$NetsenderLogFile" ]]; then
  dir=$(dirname "$NetsenderLogFile")
  sudo mkdir -p "$dir"
  sudo chmod 777 "$dir"
  sudo chown -R "$User" "$dir"
fi

# Set up MAC address.
macs=$(bash -c "$GetWifiMac")
if [[ -z "$macs" ]]; then
  log "Error" "Failed to get MAC addresses. Generating random ones."
  h3=${RANDOM:0:2}
  h4=${RANDOM:0:2}
  h5=${RANDOM:0:2}
  macs="00:00:00:$h3:$h4:$h5 a0:a0:a0:$h3:$h4:$h5"
fi

WI=${macs%% *}
MA=${macs#* }
log "Info" "MAC addresses $macs"

# Assign MAC address to ethernet device eth0.
if [[ -n $(isRaspbian) ]]; then
  log "Info" "Setting eth0 address to $MA"
  sudo ifconfig eth0 down
  sudo ifconfig eth0 hw ether "$MA"
  sudo ifconfig eth0 up
  status=$(ip link show eth0 | grep 'state UP')
  if [[ -n "$status" ]]; then
    log "Info" "eth0 is UP."
    Eth0IsUp=1
  else
    log "Error" "eth0 is DOWN."
  fi
fi

# Loop until we know our client type.
CT=
while true; do
  CT=$(configure)
  if [[ -n "$CT" ]]; then
    break
  fi
  log "Info" "Sleeping..."
  sleep "$RetryPeriod"
done

# Set binary based on client type.
Bin=
case "$CT" in
  "camera")
    Bin="rv"
    ;;
  "hydrophone")
    Bin="rv"
    ;;
  "speaker")
    Bin="speaker"
    ;;
  "test")
    Bin="shell-netsender.sh"
    ;;
  *)
    log "Fatal" "Unknown client type: $CT"
    ;;
esac

# Prepend binary directory to the PATH.
export PATH=$BinDir:$PATH

# Check if the binary is installed or install it.
BinPath=$BinDir/$Bin
if [[ ! -f "$BinPath" ]]; then
  log "Info" "No '$Bin' binary found. Installing..."
  log "Info" "$PkgUpgrade $CT @latest prereq"
  sudo -u $User PATH=$PATH bash -c "$PkgUpgrade $CT @latest prereq"
  if [[ $? -eq 0 ]]; then
    log "Info" "Successfully installed $CT".
  else
    log "Fatal" "$CT installation failed".
  fi
fi

# Set kernel parameters to improve performance on Raspberry Pi
# and disable wlan0 providing etho is UP.
if [[ -n $(isRaspbian) ]]; then
  log "Info" "Setting kernel parameters"
  # Tell Linux to fork optimistically.
  sudo sysctl -w vm.overcommit_memory=1
  # Minimize swapping, without disabling it completely.
  sudo sysctl -w vm.swappiness=1
  # Silence Wi-Fi and BT completely when eth0 is up.
  if [[ -n "$Eth0IsUp" ]]; then
    wifi_bt_off
  else
    wifi_bt_on
  fi
fi

# Update the ssh banner
update_ssh_banner

# Launch the binary running as the given user.
log "Info" "Running $BinPath"
sudo -u $User PATH=$PATH $BinPath
if [[ $? -eq 0 ]]; then
  log "Info" "Successfully exited $BinPath"
  exit 0
else
  log "Error" "$BinPath exited with code: $?"
  exit 1
fi
